# 随身单词本 PocketWords (Android)

第一版 Kotlin 原生 Android Studio 项目，包含：
- 简洁的单词列表界面
- 本地收藏、去重、删除（SharedPreferences）
- 可拖动的悬浮按钮
- 首次点击悬浮按钮后请求 Android 系统屏幕捕获授权
- 在同一有效 MediaProjection 会话中重复请求屏幕帧，并使用 Google ML Kit Latin OCR 识别英文
- 前台通知提供“停止取词”操作；系统撤销会话后需要重新授权
- 用户可以编辑识别结果后收藏

## 环境
- Android Studio（建议最新稳定版）
- JDK 17（Android Studio 自带 JBR 也可）
- Android SDK Platform 35
- 网络连接（首次 Gradle 同步需要下载 Android Gradle Plugin、Kotlin 插件和 ML Kit 依赖）

## 打开和编译
1. 解压 ZIP。
2. Android Studio 选择 **Open**，选中 `PocketWords` 文件夹（包含 `settings.gradle.kts`）。
3. 等待 Gradle Sync 完成；如果提示安装 SDK Platform 35，点击安装。
4. 连接 Android 手机，打开开发者选项和 USB 调试，或使用 Android Studio 的 Device Manager 创建模拟器。
5. 点击 **Build > Build Bundle(s) / APK(s) > Build APK(s)**。
6. APK 通常输出在 `app/build/outputs/apk/debug/app-debug.apk`。

## 手机上首次使用
1. 安装 APK 并打开“随身单词本”。
2. 点击“开启取词悬浮球”。
3. 在系统设置中允许“显示在其他应用上层”，返回 App 再点一次。
4. 打开一篇英文文章，点击屏幕上的“词”悬浮球。
5. 第一次点击时，系统会显示屏幕共享/录制授权页面；确认后 App 开始取词会话并识别一帧屏幕图像。
6. 会话仍然有效时，再点击悬浮球会请求下一次识别，不会每次都重新申请授权。
7. 可在前台通知中点“停止取词”结束会话；系统撤销或结束会话后，下次使用需要重新授权。
8. 在识别结果弹窗里删除不需要的文字，只保留目标单词或短语，再点“收藏”。

## 注意
- 该项目没有预编译 APK；需用 Android Studio 编译。
- MediaProjection 必须经过系统授权；系统可能在通知栏显示屏幕捕获状态。
- 某些视频、DRM 页面、银行/密码页面会阻止截图或显示黑屏。
- OCR 结果取决于字体、分辨率和页面布局；请在收藏前检查并编辑。
- 本版保存的是单词/短语文本，尚未集成词典释义、音标、TTS 发音、间隔复习和导出。
- 这是第一版代码，需在目标手机上实测并根据 Android 厂商后台限制调整。
