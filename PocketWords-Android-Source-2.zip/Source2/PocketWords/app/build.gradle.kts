plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.pocketwords.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.pocketwords.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}


// Download the MIT-licensed ECDICT SQLite dictionary at build time, then package it
// as an offline asset. The dictionary is not bundled in the source ZIP itself.
val offlineDictionaryAssets = layout.buildDirectory.dir("generated/offlineDictionaryAssets")
val prepareOfflineDictionary by tasks.registering {
    outputs.file(offlineDictionaryAssets.map { it.file("dictionary.db") })
    doLast {
        val outputDir = offlineDictionaryAssets.get().asFile
        outputDir.mkdirs()
        val dbOutput = outputDir.resolve("dictionary.db")
        if (!dbOutput.exists() || dbOutput.length() == 0L) {
            val archiveFile = layout.buildDirectory.file("ecdict-sqlite-28.zip").get().asFile
            archiveFile.parentFile.mkdirs()
            val sourceUrl = java.net.URL("https://github.com/skywind3000/ECDICT/releases/download/1.0.28/ecdict-sqlite-28.zip")
            sourceUrl.openStream().use { input -> archiveFile.outputStream().use { output -> input.copyTo(output) } }
            var found = false
            java.util.zip.ZipInputStream(archiveFile.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.substringAfterLast("/") == "stardict.db") {
                        dbOutput.outputStream().use { output -> zip.copyTo(output) }
                        found = true
                        break
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            if (!found || !dbOutput.exists() || dbOutput.length() == 0L) {
                throw GradleException("ECDICT archive downloaded, but stardict.db was not found.")
            }
        }
    }
}

android.sourceSets.getByName("main").assets.srcDir(offlineDictionaryAssets)
tasks.named("preBuild").configure { dependsOn(prepareOfflineDictionary) }
