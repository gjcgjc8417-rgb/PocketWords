package com.pocketwords.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class WordEntry(val word: String, val meaning: String)

object WordStore {
    private const val PREFS = "pocket_words"
    private const val KEY_WORDS = "words"

    fun allEntries(context: Context): List<WordEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_WORDS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val entries = mutableListOf<WordEntry>()
        for (i in 0 until arr.length()) {
            when (val item = arr.opt(i)) {
                is JSONObject -> {
                    val word = item.optString("word").trim()
                    if (word.isNotBlank()) entries.add(WordEntry(word, item.optString("meaning", "释义待补充")))
                }
                is String -> if (item.isNotBlank()) entries.add(WordEntry(item.trim(), lookupMeaning(item.trim())))
            }
        }
        return entries.distinctBy { it.word.lowercase() }
    }

    fun all(context: Context): List<String> = allEntries(context).map { it.word }

    fun add(context: Context, word: String): Boolean = add(context, word, lookupMeaning(word))

    fun add(context: Context, word: String, meaning: String): Boolean {
        val clean = word.trim().replace(Regex("\\s+"), " ").trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '"', '\'')
        if (clean.isBlank()) return false
        val current = allEntries(context)
        if (current.any { it.word.equals(clean, ignoreCase = true) }) return false
        val updated = listOf(WordEntry(clean, meaning.trim().ifBlank { "释义待补充" })) + current
        val arr = JSONArray()
        updated.forEach { arr.put(JSONObject().put("word", it.word).put("meaning", it.meaning)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
        return true
    }

    fun updateMeaning(context: Context, word: String, meaning: String) {
        val arr = JSONArray()
        allEntries(context).forEach { entry ->
            arr.put(JSONObject().put("word", entry.word).put("meaning", if (entry.word.equals(word, true)) meaning else entry.meaning))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
    }

    fun delete(context: Context, word: String) {
        val arr = JSONArray()
        allEntries(context).filterNot { it.word == word }.forEach { arr.put(JSONObject().put("word", it.word).put("meaning", it.meaning)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
    }

    fun lookupMeaning(word: String): String {
        val key = word.lowercase().trim()
        return COMMON_MEANINGS[key] ?: "释义待补充（可点击编辑）"
    }

    private val COMMON_MEANINGS = mapOf(
        "consistent" to "adj. 始终如一的；持续的", "effort" to "n. 努力；成就", "experience" to "n. 经历；经验 v. 经历",
        "achieve" to "v. 实现；达到", "improve" to "v. 改善；提高", "important" to "adj. 重要的", "different" to "adj. 不同的",
        "environment" to "n. 环境", "opportunity" to "n. 机会", "develop" to "v. 发展；培养", "consider" to "v. 考虑",
        "although" to "conj. 虽然；尽管", "however" to "adv. 然而", "therefore" to "adv. 因此", "require" to "v. 需要；要求",
        "increase" to "v./n. 增加；增长", "reduce" to "v. 减少；降低", "support" to "v./n. 支持", "available" to "adj. 可获得的；有空的",
        "benefit" to "n./v. 益处；使受益", "research" to "n./v. 研究", "education" to "n. 教育", "opinion" to "n. 观点；意见",
        "decision" to "n. 决定", "possible" to "adj. 可能的", "continue" to "v. 继续", "successful" to "adj. 成功的",
        "challenge" to "n. 挑战 v. 向……挑战", "knowledge" to "n. 知识", "similar" to "adj. 相似的", "especially" to "adv. 尤其；特别"
    )
}
