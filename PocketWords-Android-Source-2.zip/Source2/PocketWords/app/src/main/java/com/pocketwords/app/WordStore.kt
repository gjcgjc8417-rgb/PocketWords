package com.pocketwords.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class WordEntry(val word: String, val meaning: String)

object WordStore {
    private const val PREFS = "pocket_words"
    private const val KEY_WORDS = "words"

    fun allEntries(context: Context): List<WordEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_WORDS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val entries = mutableListOf<WordEntry>()
        for (i in 0 until arr.length()) {
            when (val item = arr.opt(i)) {
                is JSONObject -> {
                    val word = item.optString("word").trim()
                    if (word.isNotBlank()) {
                        val savedMeaning = item.optString("meaning", "释义待补充")
                        val meaning = if (savedMeaning.startsWith("释义待补充")) lookupMeaning(word) else savedMeaning
                        entries.add(WordEntry(word, meaning))
                    }
                }
                is String -> if (item.isNotBlank()) entries.add(WordEntry(item.trim(), lookupMeaning(item.trim())))
            }
        }
        return entries.distinctBy { it.word.lowercase() }
    }

    fun all(context: Context): List<String> = allEntries(context).map { it.word }

    fun add(context: Context, word: String): Boolean = add(context, word, lookupMeaning(word))

    fun add(context: Context, word: String, meaning: String): Boolean {
        val clean = word.trim().replace(Regex("\\s+"), " ").trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '"', '\'')
        if (clean.isBlank()) return false
        val current = allEntries(context)
        if (current.any { it.word.equals(clean, ignoreCase = true) }) return false
        val updated = listOf(WordEntry(clean, meaning.trim().ifBlank { "释义待补充" })) + current
        val arr = JSONArray()
        updated.forEach { arr.put(JSONObject().put("word", it.word).put("meaning", it.meaning)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
        return true
    }

    fun updateMeaning(context: Context, word: String, meaning: String) {
        val arr = JSONArray()
        allEntries(context).forEach { entry ->
            arr.put(JSONObject().put("word", entry.word).put("meaning", if (entry.word.equals(word, true)) meaning else entry.meaning))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
    }

    fun delete(context: Context, word: String) {
        val arr = JSONArray()
        allEntries(context).filterNot { it.word == word }.forEach { arr.put(JSONObject().put("word", it.word).put("meaning", it.meaning)) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
    }

    fun lookupMeaning(word: String): String {
        val key = word.lowercase().trim().trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '"', '\'')
        COMMON_MEANINGS[key]?.let { return it }
        // Try common inflected forms so words such as "studies", "worked" and "running"
        // can reuse a known offline dictionary entry. Only return a meaning when the base
        // word is actually present; otherwise keep the manual-edit fallback.
        val candidates = linkedSetOf<String>()
        if (key.endsWith("ies") && key.length > 4) candidates.add(key.dropLast(3) + "y")
        if (key.endsWith("es") && key.length > 4) {
            candidates.add(key.dropLast(2))
            candidates.add(key.dropLast(1))
        }
        if (key.endsWith("s") && key.length > 3) candidates.add(key.dropLast(1))
        if (key.endsWith("ied") && key.length > 4) candidates.add(key.dropLast(3) + "y")
        if (key.endsWith("ed") && key.length > 4) {
            candidates.add(key.dropLast(2))
            candidates.add(key.dropLast(1))
        }
        if (key.endsWith("ing") && key.length > 5) {
            val base = key.dropLast(3)
            candidates.add(base)
            candidates.add(base + "e")
            if (base.length > 2 && base.last() == base[base.length - 2]) candidates.add(base.dropLast(1))
        }
        for (candidate in candidates) COMMON_MEANINGS[candidate]?.let { return it }
        return "释义待补充（可点击编辑）"
    }

    private val COMMON_MEANINGS = mapOf(
        "consistent" to "adj. 始终如一的；持续的", "effort" to "n. 努力；成就", "experience" to "n. 经历；经验 v. 经历",
        "achieve" to "v. 实现；达到", "improve" to "v. 改善；提高", "important" to "adj. 重要的", "different" to "adj. 不同的",
        "environment" to "n. 环境", "opportunity" to "n. 机会", "develop" to "v. 发展；培养", "consider" to "v. 考虑",
        "although" to "conj. 虽然；尽管", "however" to "adv. 然而", "therefore" to "adv. 因此", "require" to "v. 需要；要求",
        "increase" to "v./n. 增加；增长", "reduce" to "v. 减少；降低", "support" to "v./n. 支持", "available" to "adj. 可获得的；有空的",
        "benefit" to "n./v. 益处；使受益", "research" to "n./v. 研究", "education" to "n. 教育", "opinion" to "n. 观点；意见",
        "decision" to "n. 决定", "possible" to "adj. 可能的", "continue" to "v. 继续", "successful" to "adj. 成功的",
        "challenge" to "n. 挑战 v. 向……挑战", "knowledge" to "n. 知识", "similar" to "adj. 相似的", "especially" to "adv. 尤其；特别",
        "ability" to "n. 能力；才能", "able" to "adj. 能够……的", "about" to "prep. 关于；大约", "above" to "prep./adv. 在……上方；超过",
        "accept" to "v. 接受；认可", "according" to "prep. 根据；按照", "account" to "n. 账户；描述；解释", "accurate" to "adj. 准确的",
        "across" to "prep./adv. 横过；在对面", "act" to "v. 行动；表现 n. 行为", "action" to "n. 行动；措施", "active" to "adj. 积极的；活跃的",
        "activity" to "n. 活动", "actually" to "adv. 实际上；事实上", "add" to "v. 添加；补充", "address" to "n. 地址；演讲 v. 处理",
        "admit" to "v. 承认；准许进入", "adult" to "n. 成年人 adj. 成年的", "advance" to "n./v. 前进；进展", "advantage" to "n. 优点；优势",
        "advice" to "n. 建议", "advise" to "v. 建议；劝告", "affect" to "v. 影响", "afford" to "v. 买得起；承担得起",
        "afraid" to "adj. 害怕的", "after" to "prep./conj. 在……之后", "afternoon" to "n. 下午", "again" to "adv. 再一次",
        "against" to "prep. 反对；对着；靠着", "age" to "n. 年龄；时代", "agency" to "n. 机构；代理处", "agree" to "v. 同意；一致",
        "agreement" to "n. 协议；同意", "ahead" to "adv. 向前；提前", "aim" to "n./v. 目标；旨在", "air" to "n. 空气；航空",
        "allow" to "v. 允许；准许", "almost" to "adv. 几乎", "alone" to "adj./adv. 独自的（地）", "along" to "prep./adv. 沿着；一起",
        "already" to "adv. 已经", "also" to "adv. 也；而且", "alternative" to "n. 替代选择 adj. 可替代的", "among" to "prep. 在……之中",
        "amount" to "n. 数量 v. 总计", "analysis" to "n. 分析", "analyze" to "v. 分析", "ancient" to "adj. 古代的；古老的",
        "anger" to "n. 愤怒", "angle" to "n. 角度；观点", "animal" to "n. 动物", "announce" to "v. 宣布；通知",
        "announcement" to "n. 通告；宣布", "annual" to "adj. 每年的 n. 年刊", "another" to "det./pron. 另一个；再一个", "answer" to "n./v. 答案；回答",
        "anxiety" to "n. 焦虑；担忧", "anxious" to "adj. 焦虑的；渴望的", "any" to "det./pron. 任何；一些", "anyone" to "pron. 任何人",
        "anything" to "pron. 任何事物", "anyway" to "adv. 无论如何", "appear" to "v. 出现；似乎", "appearance" to "n. 外貌；出现",
        "apply" to "v. 申请；应用；涂抹", "application" to "n. 申请；应用程序", "approach" to "n./v. 方法；接近", "appropriate" to "adj. 合适的",
        "area" to "n. 地区；领域；面积", "argue" to "v. 争论；论证", "argument" to "n. 争论；论据", "arise" to "v. 发生；出现",
        "arm" to "n. 手臂；武器 v. 武装", "army" to "n. 军队", "around" to "prep./adv. 在周围；大约", "arrange" to "v. 安排；整理",
        "arrangement" to "n. 安排；布置", "arrive" to "v. 到达", "article" to "n. 文章；物品；冠词", "artist" to "n. 艺术家",
        "as" to "conj./prep./adv. 当……时；作为；像", "aspect" to "n. 方面；外观", "assess" to "v. 评估；评价", "assessment" to "n. 评估；评价",
        "assignment" to "n. 作业；任务；分配", "assist" to "v. 帮助；协助", "assistance" to "n. 帮助；援助", "assistant" to "n. 助手 adj. 助理的",
        "associate" to "v. 联系；联想 n. 同事", "association" to "n. 协会；联系", "assume" to "v. 假定；承担", "assumption" to "n. 假设；假定",
        "attention" to "n. 注意；关注", "attitude" to "n. 态度；看法", "attract" to "v. 吸引", "attraction" to "n. 吸引力；景点",
        "audience" to "n. 观众；听众；读者", "author" to "n. 作者", "authority" to "n. 权威；当局；权限", "average" to "n./adj./v. 平均数；平均的；平均为",
        "avoid" to "v. 避免；躲开", "aware" to "adj. 意识到的；知道的", "awareness" to "n. 意识；认识", "background" to "n. 背景；经历",
        "balance" to "n./v. 平衡；余额", "basic" to "adj. 基本的 n. 基础要素", "basis" to "n. 基础；依据", "because" to "conj. 因为",
        "become" to "v. 变成；成为", "behavior" to "n. 行为；举止", "believe" to "v. 相信；认为", "belong" to "v. 属于",
        "below" to "prep./adv. 在……下面；低于", "beneficial" to "adj. 有益的", "besides" to "prep./adv. 除……之外；此外", "between" to "prep. 在两者之间",
        "beyond" to "prep./adv. 超出；在更远处", "billion" to "num./n. 十亿", "biology" to "n. 生物学", "birth" to "n. 出生；诞生",
        "blame" to "v./n. 责备；责任", "blood" to "n. 血液", "board" to "n. 木板；委员会；董事会 v. 登机", "body" to "n. 身体；主体",
        "book" to "n. 书 v. 预订", "borrow" to "v. 借入", "brain" to "n. 大脑；智力", "branch" to "n. 树枝；分支；分部",
        "break" to "v./n. 打破；休息", "brief" to "adj. 简短的 n. 摘要", "briefly" to "adv. 简短地", "bright" to "adj. 明亮的；聪明的",
        "brilliant" to "adj. 杰出的；明亮的", "bring" to "v. 带来；拿来", "broad" to "adj. 宽阔的；广泛的", "budget" to "n. 预算",
        "build" to "v. 建造；建立", "building" to "n. 建筑物", "business" to "n. 生意；商业；事务", "busy" to "adj. 忙碌的",
        "calculate" to "v. 计算；估算", "calculation" to "n. 计算", "career" to "n. 职业；事业", "careful" to "adj. 小心的；仔细的",
        "carefully" to "adv. 仔细地", "cause" to "n. 原因 v. 引起", "central" to "adj. 中心的；主要的", "century" to "n. 世纪；百年",
        "certain" to "adj. 确定的；某个", "certainly" to "adv. 当然；无疑", "certainty" to "n. 确定性", "chance" to "n. 机会；可能性",
        "change" to "n./v. 改变；变化", "character" to "n. 性格；人物；字符", "characteristic" to "n. 特征 adj. 典型的", "charge" to "n./v. 费用；收费；指控；充电",
        "choice" to "n. 选择", "choose" to "v. 选择", "circumstance" to "n. 情况；环境", "claim" to "v./n. 声称；索赔；主张",
        "clear" to "adj./v. 清楚的；清除", "clearly" to "adv. 清楚地；显然", "climate" to "n. 气候；氛围", "close" to "v./adj./adv. 关闭；近的；接近地",
        "closely" to "adv. 密切地；仔细地", "coast" to "n. 海岸", "collect" to "v. 收集；收藏", "collection" to "n. 收集；收藏品",
        "college" to "n. 学院；大学", "combine" to "v. 结合；联合", "combination" to "n. 结合；组合", "comfortable" to "adj. 舒适的",
        "comment" to "n./v. 评论", "common" to "adj. 常见的；共同的", "communicate" to "v. 交流；沟通", "communication" to "n. 交流；通信",
        "community" to "n. 社区；群体", "compare" to "v. 比较；对比", "comparison" to "n. 比较", "compete" to "v. 竞争；比赛",
        "competition" to "n. 竞争；比赛", "competitive" to "adj. 有竞争力的", "competitor" to "n. 竞争者", "complain" to "v. 抱怨；投诉",
        "complaint" to "n. 抱怨；投诉", "complete" to "adj./v. 完整的；完成", "completely" to "adv. 完全地", "complex" to "adj. 复杂的 n. 综合体",
        "complicated" to "adj. 复杂的", "component" to "n. 组成部分；零件", "concentrate" to "v. 集中；专心", "concentration" to "n. 专注；浓度",
        "concept" to "n. 概念；观念", "concern" to "n./v. 担忧；涉及", "concerned" to "adj. 担心的；相关的", "conclusion" to "n. 结论；结束",
        "condition" to "n. 条件；状况", "conduct" to "v. 进行；引导 n. 行为", "confidence" to "n. 信心；信任", "confident" to "adj. 自信的；确信的",
        "conflict" to "n./v. 冲突；抵触", "confuse" to "v. 使困惑；混淆", "confused" to "adj. 困惑的", "confusing" to "adj. 令人困惑的",
        "connection" to "n. 联系；连接", "consequence" to "n. 结果；后果", "consequently" to "adv. 因此；结果", "considerable" to "adj. 相当大的；重要的",
        "consist" to "v. 由……组成；在于", "constant" to "adj. 持续的；不变的 n. 常数", "constantly" to "adv. 不断地", "construct" to "v. 建造；构建",
        "construction" to "n. 建设；建造", "consumer" to "n. 消费者", "consumption" to "n. 消费；消耗", "contact" to "n./v. 联系；接触",
        "contain" to "v. 包含；容纳", "content" to "n. 内容 adj. 满足的", "context" to "n. 上下文；背景", "contract" to "n. 合同 v. 收缩",
        "contribute" to "v. 贡献；促成；投稿", "contribution" to "n. 贡献；捐款", "control" to "n./v. 控制", "convenient" to "adj. 方便的",
        "conversation" to "n. 对话；谈话", "convince" to "v. 使信服；说服", "cooperate" to "v. 合作", "cooperation" to "n. 合作",
        "cost" to "n./v. 费用；花费", "creative" to "adj. 有创造力的", "creativity" to "n. 创造力", "create" to "v. 创造；创建",
        "creation" to "n. 创造；作品", "crime" to "n. 犯罪；罪行", "criminal" to "n. 罪犯 adj. 犯罪的", "critical" to "adj. 批判性的；关键的",
        "criticism" to "n. 批评；评论", "criticize" to "v. 批评；指责", "culture" to "n. 文化", "cultural" to "adj. 文化的",
        "curious" to "adj. 好奇的", "curiosity" to "n. 好奇心", "current" to "adj. 当前的 n. 水流；电流", "currently" to "adv. 目前；当前",
        "customer" to "n. 顾客；客户", "daily" to "adj./adv. 每日的（地） n. 日报", "damage" to "n./v. 损害；破坏", "data" to "n. 数据",
        "deal" to "n./v. 交易；处理；对待", "debate" to "n./v. 辩论；讨论", "decade" to "n. 十年", "decline" to "v./n. 下降；拒绝",
        "decrease" to "v./n. 减少；下降", "deep" to "adj./adv. 深的（地）", "deeply" to "adv. 深深地；非常", "define" to "v. 定义；界定",
        "definition" to "n. 定义；释义", "degree" to "n. 程度；学位；度数", "deliver" to "v. 递送；发表；交付", "delivery" to "n. 递送；交付",
        "demand" to "n./v. 需求；要求", "demonstrate" to "v. 证明；演示", "demonstration" to "n. 证明；演示", "depend" to "v. 依靠；取决于",
        "dependent" to "adj. 依赖的", "describe" to "v. 描述", "description" to "n. 描述；说明", "design" to "n./v. 设计",
        "designer" to "n. 设计师", "desire" to "n./v. 渴望；愿望", "detail" to "n. 细节 v. 详述", "detailed" to "adj. 详细的",
        "determine" to "v. 决定；测定", "determination" to "n. 决心；测定", "determine" to "v. 决定；确定", "development" to "n. 发展；开发",
        "device" to "n. 设备；装置", "difference" to "n. 差异；不同", "difficulty" to "n. 困难；难度", "direct" to "adj./v. 直接的；指导",
        "direction" to "n. 方向；指示", "directly" to "adv. 直接地；立即", "disadvantage" to "n. 缺点；不利条件", "disagree" to "v. 不同意",
        "disappear" to "v. 消失", "disappoint" to "v. 使失望", "disappointed" to "adj. 失望的", "disappointing" to "adj. 令人失望的",
        "discover" to "v. 发现", "discovery" to "n. 发现", "discuss" to "v. 讨论", "discussion" to "n. 讨论",
        "disease" to "n. 疾病", "display" to "v./n. 展示；显示屏", "distance" to "n. 距离", "distant" to "adj. 遥远的；疏远的",
        "distinguish" to "v. 区分；辨别", "distinction" to "n. 区别；卓越", "distribute" to "v. 分发；分配", "distribution" to "n. 分发；分布",
        "divide" to "v. 分开；除以", "division" to "n. 分割；部门；除法", "document" to "n. 文件 v. 记录", "domestic" to "adj. 国内的；家庭的",
        "double" to "adj./v. 双倍的；加倍", "doubt" to "n./v. 怀疑", "doubtful" to "adj. 怀疑的；不确定的", "down" to "adv./prep. 向下；沿着",
        "download" to "v./n. 下载", "due" to "adj. 预定的；应有的；因为", "duty" to "n. 责任；职责；税"
    )
}
