package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var countLabel: TextView
    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty()
            runOnUiThread { showRecognizedText(text) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val filter = IntentFilter(CaptureService.ACTION_OCR_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureReceiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(captureReceiver, filter)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(16))
            setBackgroundColor(0xFFF7F9F8.toInt())
        }
        val title = TextView(this).apply { text = "随身单词本"; textSize = 28f; setTextColor(0xFF18332B.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(title)
        root.addView(TextView(this).apply { text = "看到生词，随手收藏。每天积累一点。"; textSize = 14f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(5), 0, dp(18)) })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        buttons.addView(Button(this).apply { text = "开启取词悬浮球"; setOnClickListener { enableOverlay() } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(Button(this).apply { text = "手动添加"; setOnClickListener { showAddDialog("") } }, LinearLayout.LayoutParams(dp(110), dp(48)))
        root.addView(buttons)
        countLabel = TextView(this).apply { textSize = 16f; setTextColor(0xFF18332B.toInt()); setPadding(0, dp(22), 0, dp(10)) }
        root.addView(countLabel)
        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(TextView(this).apply { text = "提示：首次点击悬浮球需要系统授权；会话有效期间可重复识别。识别结果可编辑后再收藏。"; textSize = 12f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(10), 0, 0) })
        setContentView(root)
        refreshWords()
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "请允许‘随身单词本’显示在其他应用上层，然后返回再点一次。", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "悬浮球已开启，可打开英文页面后点击它。", Toast.LENGTH_LONG).show()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == OverlayService.ACTION_CAPTURE) {
            if (CaptureService.sessionActive) {
                // Reuse the existing MediaProjection session for another OCR request.
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }
    }

    @Deprecated("Android screen-capture consent uses activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else if (requestCode == REQUEST_CAPTURE) {
            Toast.makeText(this, "你取消了屏幕捕获。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showRecognizedText(text: String) {
        if (text.isBlank()) {
            Toast.makeText(this, "没有识别到清晰的文字，请换个页面再试。", Toast.LENGTH_LONG).show()
            return
        }
        val input = EditText(this).apply { setText(text); setSelection(text.length); hint = "编辑为要收藏的单词或短语"; minLines = 3; gravity = Gravity.TOP }
        AlertDialog.Builder(this).setTitle("屏幕识别结果").setMessage("删除不需要的文字，只保留你想收藏的单词或短语。")
            .setView(input)
            .setNegativeButton("取消", null)
            .setNeutralButton("复制全部", null)
            .setPositiveButton("收藏") { _, _ ->
                val value = input.text.toString().trim()
                if (WordStore.add(this, value)) Toast.makeText(this, "已收藏", Toast.LENGTH_SHORT).show()
                else Toast.makeText(this, "内容为空或已经收藏", Toast.LENGTH_SHORT).show()
                refreshWords()
            }.show().getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("OCR text", input.text.toString()))
                Toast.makeText(this, "已复制识别文字", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showAddDialog(initial: String) {
        val input = EditText(this).apply { hint = "例如：consistent"; setText(initial) }
        AlertDialog.Builder(this).setTitle("添加单词").setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("收藏") { _, _ ->
                val added = WordStore.add(this, input.text.toString())
                Toast.makeText(this, if (added) "已收藏" else "内容为空或已经收藏", Toast.LENGTH_SHORT).show()
                refreshWords()
            }.show()
    }

    private fun refreshWords() {
        if (!::listContainer.isInitialized) return
        val words = WordStore.all(this)
        countLabel.text = "我的生词 · ${words.size}"
        listContainer.removeAllViews()
        if (words.isEmpty()) {
            listContainer.addView(TextView(this).apply { text = "还没有收藏的单词。\n打开英文文章，试试悬浮取词吧。"; textSize = 15f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(20), 0, dp(20)) })
        }
        words.forEach { word ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(4), dp(8)); setBackgroundColor(0xFFFFFFFF.toInt()) }
            row.addView(TextView(this).apply { text = word; textSize = 17f; setTextColor(0xFF18332B.toInt()); setPadding(0, dp(8), 0, dp(8)) }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "删除"; setOnClickListener { WordStore.delete(this@MainActivity, word); refreshWords() } })
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(8)
            listContainer.addView(row, params)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_CAPTURE = 4102 }
}
