package com.pocketwords.app

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import org.json.JSONArray
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var listContainer: LinearLayout
    private lateinit var countLabel: TextView
    private val captureReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra(CaptureService.EXTRA_TEXT).orEmpty()
            val imagePath = intent?.getStringExtra(CaptureService.EXTRA_IMAGE_PATH).orEmpty()
            val boxes = intent?.getStringExtra(CaptureService.EXTRA_WORD_BOXES).orEmpty()
            val width = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_WIDTH, 0) ?: 0
            val height = intent?.getIntExtra(CaptureService.EXTRA_IMAGE_HEIGHT, 0) ?: 0
            runOnUiThread { showWordSelection(text, imagePath, boxes, width, height) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val filter = IntentFilter(CaptureService.ACTION_OCR_RESULT)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(captureReceiver, filter, RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(captureReceiver, filter)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onDestroy() {
        try { unregisterReceiver(captureReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(16))
            setBackgroundColor(0xFFF7F9F8.toInt())
        }
        val title = TextView(this).apply { text = "随身单词本"; textSize = 28f; setTextColor(0xFF18332B.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD }
        root.addView(title)
        root.addView(TextView(this).apply { text = "看到生词，随手收藏。每天积累一点。"; textSize = 14f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(5), 0, dp(18)) })

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        buttons.addView(Button(this).apply { text = "开启取词悬浮球"; setOnClickListener { enableOverlay() } }, LinearLayout.LayoutParams(0, dp(48), 1f))
        buttons.addView(Button(this).apply { text = "手动添加"; setOnClickListener { showAddDialog("") } }, LinearLayout.LayoutParams(dp(110), dp(48)))
        root.addView(buttons)
        countLabel = TextView(this).apply { textSize = 16f; setTextColor(0xFF18332B.toInt()); setPadding(0, dp(22), 0, dp(10)) }
        root.addView(countLabel)
        val scroll = ScrollView(this)
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listContainer)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(TextView(this).apply { text = "提示：首次点击悬浮球需要系统授权；会话有效期间可重复识别。识别结果可编辑后再收藏。"; textSize = 12f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(10), 0, 0) })
        setContentView(root)
        refreshWords()
    }

    private fun enableOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "请允许‘随身单词本’显示在其他应用上层，然后返回再点一次。", Toast.LENGTH_LONG).show()
            return
        }
        startService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "悬浮球已开启，可打开英文页面后点击它。", Toast.LENGTH_LONG).show()
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == OverlayService.ACTION_CAPTURE) {
            if (CaptureService.sessionActive) {
                // Reuse the existing MediaProjection session for another OCR request.
                startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
            } else {
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
            }
        }
    }

    @Deprecated("Android screen-capture consent uses activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        } else if (requestCode == REQUEST_CAPTURE) {
            Toast.makeText(this, "你取消了屏幕捕获。", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showWordSelection(text: String, imagePath: String, boxesJson: String, imageWidth: Int, imageHeight: Int) {
        if (text.isBlank() || imagePath.isBlank()) {
            Toast.makeText(this, "没有识别到清晰文字。请放大英文内容、换个页面后重试。", Toast.LENGTH_LONG).show()
            return
        }
        val bitmap = try { BitmapFactory.decodeFile(imagePath) } catch (_: Exception) { null }
        if (bitmap == null) {
            showRecognizedTextFallback(text)
            return
        }
        val boxes = mutableListOf<WordBox>()
        try {
            val arr = JSONArray(boxesJson)
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                boxes.add(WordBox(item.optString("text"), item.optInt("left"), item.optInt("top"), item.optInt("right"), item.optInt("bottom")))
            }
        } catch (_: Exception) {}
        val selectionView = WordSelectionView(bitmap, boxes, imageWidth.takeIf { it > 0 } ?: bitmap.width, imageHeight.takeIf { it > 0 } ?: bitmap.height) { selected ->
            showSelectedWordDialog(selected)
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
            addView(TextView(this@MainActivity).apply {
                this.text = "点截图中你要收藏的英文单词。识别不准时，可用下方手动添加。"
                textSize = 14f; setTextColor(0xFF53645C.toInt()); setPadding(dp(4), dp(4), dp(4), dp(10))
            })
            addView(selectionView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(440)))
            addView(Button(this@MainActivity).apply { this.text = "没找到？手动输入单词"; setOnClickListener { showAddDialog("") } }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
        }
        AlertDialog.Builder(this).setTitle("点选要收藏的单词")
            .setView(container).setNegativeButton("关闭", null)
            .setNeutralButton("重新识别", null)
            .show().also { dialog ->
                dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                    dialog.dismiss()
                    if (CaptureService.sessionActive) startService(Intent(this, CaptureService::class.java).setAction(CaptureService.ACTION_CAPTURE_ONCE))
                    else Toast.makeText(this, "请重新点击悬浮球并授权屏幕捕获。", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun showSelectedWordDialog(word: String) {
        val clean = word.trim().trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '"', '\'')
        if (clean.isBlank()) return
        val meaningInput = EditText(this).apply {
            setText(WordStore.lookupMeaning(this@MainActivity, clean))
            hint = "输入中文释义"
            minLines = 2
        }
        AlertDialog.Builder(this).setTitle(clean).setMessage("确认单词和中文释义")
            .setView(meaningInput).setNegativeButton("取消", null)
            .setPositiveButton("收藏单词") { _, _ ->
                val meaning = meaningInput.text.toString().trim().ifBlank { "释义待补充（可稍后编辑）" }
                val added = WordStore.add(this, clean, meaning)
                Toast.makeText(this, if (added) "已收藏：$clean" else "这个单词已经在单词本里了", Toast.LENGTH_SHORT).show()
                refreshWords()
            }.show()
    }

    private fun showRecognizedTextFallback(text: String) {
        val input = EditText(this).apply { setText(text); hint = "输入要收藏的单词" }
        AlertDialog.Builder(this).setTitle("识别结果（备用方式）").setView(input)
            .setNegativeButton("取消", null).setPositiveButton("继续") { _, _ -> showSelectedWordDialog(input.text.toString()) }.show()
    }

    private data class WordBox(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int)

    private inner class WordSelectionView(
        private val bitmap: Bitmap,
        private val boxes: List<WordBox>,
        private val sourceWidth: Int,
        private val sourceHeight: Int,
        private val onWordSelected: (String) -> Unit
    ) : View(this@MainActivity) {
        private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x5532A879; style = Paint.Style.FILL }
        private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF16845D.toInt(); style = Paint.Style.STROKE; strokeWidth = dp(1).toFloat() }
        private var drawnRect = RectF()
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val drawW = bitmap.width * scale; val drawH = bitmap.height * scale
            val left = (width - drawW) / 2f; val top = (height - drawH) / 2f
            drawnRect = RectF(left, top, left + drawW, top + drawH)
            canvas.drawColor(0xFFE8ECE9.toInt())
            canvas.drawBitmap(bitmap, null, drawnRect, imagePaint)
            val sx = drawW / sourceWidth.coerceAtLeast(1); val sy = drawH / sourceHeight.coerceAtLeast(1)
            boxes.forEach { b ->
                val r = RectF(left + b.left * sx, top + b.top * sy, left + b.right * sx, top + b.bottom * sy)
                canvas.drawRoundRect(r, dp(3).toFloat(), dp(3).toFloat(), boxPaint)
                canvas.drawRoundRect(r, dp(3).toFloat(), dp(3).toFloat(), borderPaint)
            }
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_UP || drawnRect.width() <= 0f) return true
            val scale = minOf(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
            val sx = drawnRect.width() / sourceWidth.coerceAtLeast(1); val sy = drawnRect.height() / sourceHeight.coerceAtLeast(1)
            val x = (event.x - drawnRect.left) / sx; val y = (event.y - drawnRect.top) / sy
            val hit = boxes.filter { x >= it.left && x <= it.right && y >= it.top && y <= it.bottom }
                .minByOrNull { (it.right - it.left).toLong() * (it.bottom - it.top).toLong() }
            if (hit != null) onWordSelected(hit.text)
            else Toast.makeText(this@MainActivity, "请点绿色框内的英文单词；框不准确时可手动输入。", Toast.LENGTH_SHORT).show()
            return true
        }
    }

    private fun showAddDialog(initial: String) {
        val input = EditText(this).apply { hint = "例如：consistent"; setText(initial) }
        AlertDialog.Builder(this).setTitle("添加单词").setView(input)
            .setNegativeButton("取消", null)
            .setPositiveButton("收藏") { _, _ ->
                val word = input.text.toString().trim()
                if (word.isNotBlank()) showSelectedWordDialog(word)
                else Toast.makeText(this, "请输入单词", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun refreshWords() {
        if (!::listContainer.isInitialized) return
        val words = WordStore.allEntries(this)
        countLabel.text = "我的生词 · ${words.size}"
        listContainer.removeAllViews()
        if (words.isEmpty()) {
            listContainer.addView(TextView(this).apply { text = "还没有收藏的单词。\n打开英文文章，试试悬浮取词吧。"; textSize = 15f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(20), 0, dp(20)) })
        }
        words.forEach { entry ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(12), dp(8), dp(4), dp(8)); setBackgroundColor(0xFFFFFFFF.toInt()) }
            val wordsText = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            wordsText.addView(TextView(this).apply { text = entry.word; textSize = 18f; setTextColor(0xFF18332B.toInt()); typeface = android.graphics.Typeface.DEFAULT_BOLD })
            wordsText.addView(TextView(this).apply { text = entry.meaning; textSize = 13f; setTextColor(0xFF68766F.toInt()); setPadding(0, dp(3), 0, 0) })
            row.addView(wordsText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(Button(this).apply { text = "编辑"; setOnClickListener { editMeaning(entry.word, entry.meaning) } })
            row.addView(Button(this).apply { text = "删除"; setOnClickListener { WordStore.delete(this@MainActivity, entry.word); refreshWords() } })
            val params = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            params.bottomMargin = dp(8)
            listContainer.addView(row, params)
        }
    }

    private fun editMeaning(word: String, current: String) {
        val input = EditText(this).apply { setText(current); hint = "中文释义"; minLines = 2 }
        AlertDialog.Builder(this).setTitle(word).setView(input).setNegativeButton("取消", null)
            .setPositiveButton("保存释义") { _, _ -> WordStore.updateMeaning(this, word, input.text.toString().trim()); refreshWords() }.show()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    companion object { private const val REQUEST_CAPTURE = 4102 }
}
