package com.pocketwords.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private var processing = false
    private var captureRequested = false
    private var captureTimeout: Runnable? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        createNotificationChannel()
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP_CAPTURE)
        val stopPendingIntent = PendingIntent.getService(
            this, STOP_REQUEST_CODE, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("随身单词本取词已开启")
            .setContentText("点击悬浮球再次识别；可在此通知中停止取词")
            .setSmallIcon(android.R.drawable.ic_menu_search)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "停止取词", stopPendingIntent)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        when (intent.action) {
            ACTION_STOP_CAPTURE -> {
                releaseCapture()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_CAPTURE_ONCE -> {
                if (sessionActive && projection != null && imageReader != null) requestCapture()
                else sendOcrResult("")
                return START_NOT_STICKY
            }
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (data == null || resultCode == 0) {
            releaseCapture()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        // Do not create a second MediaProjection session if one is already active.
        if (sessionActive && projection != null) {
            requestCapture()
            return START_NOT_STICKY
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    // Android may revoke the session. Release resources without stopping it again.
                    if (projection != null) {
                        releaseCapture(stopProjection = false)
                        stopForeground(STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    }
                }
            }, handler)
            if (projection == null || !startCapture()) {
                releaseCapture()
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            } else {
                requestCapture() // First authorized click also performs a recognition.
            }
        } catch (_: Exception) {
            releaseCapture()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(): Boolean {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels.coerceAtLeast(1)
        val height = metrics.heightPixels.coerceAtLeast(1)
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
        imageReader = reader
        reader.setOnImageAvailableListener({ availableReader ->
            val image = try { availableReader.acquireLatestImage() } catch (_: Exception) { null } ?: return@setOnImageAvailableListener

            if (processing || !captureRequested) {
                image.close()
                return@setOnImageAvailableListener
            }

            captureRequested = false
            captureTimeout?.let { handler.removeCallbacks(it) }
            captureTimeout = null
            processing = true

            val captured: Bitmap? = try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width
                val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
                padded.recycle()
                cropped
            } catch (_: Exception) {
                null
            } finally {
                image.close()
            }

            if (captured == null) {
                processing = false
                sendOcrResult("")
                return@setOnImageAvailableListener
            }

            // Save the exact frame so the user can tap a word on the captured screen.
            val imageFile = File(cacheDir, "pocketwords-capture.png")
            try { FileOutputStream(imageFile).use { captured.compress(Bitmap.CompressFormat.PNG, 100, it) } }
            catch (_: Exception) { imageFile.delete() }
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(InputImage.fromBitmap(captured, 0))
                .addOnSuccessListener { result ->
                    val boxes = JSONArray()
                    result.textBlocks.forEach { block -> block.lines.forEach { line ->
                        line.elements.forEach { element ->
                            val word = element.text.trim()
                            val rect = element.boundingBox
                            if (word.any { it.isLetter() } && rect != null) {
                                boxes.put(JSONObject().put("text", word).put("left", rect.left).put("top", rect.top).put("right", rect.right).put("bottom", rect.bottom))
                            }
                        }
                    } }
                    sendOcrResult(result.text, if (imageFile.exists()) imageFile.absolutePath else "", boxes.toString(), captured.width, captured.height)
                }
                .addOnFailureListener { sendOcrResult("") }
                .addOnCompleteListener {
                    processing = false
                    captured.recycle()
                    recognizer.close()
                }
        }, handler)

        virtualDisplay = projection?.createVirtualDisplay(
            "PocketWordsCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, handler
        )
        sessionActive = virtualDisplay != null
        return sessionActive
    }

    private fun requestCapture() {
        if (!sessionActive || imageReader == null) {
            sendOcrResult("")
            return
        }
        captureRequested = true
        captureTimeout?.let { handler.removeCallbacks(it) }
        val timeout = Runnable {
            if (captureRequested && !processing) {
                captureRequested = false
                sendOcrResult("")
            }
        }
        captureTimeout = timeout
        handler.postDelayed(timeout, CAPTURE_TIMEOUT_MS)
    }

    private fun sendOcrResult(text: String, imagePath: String = "", boxes: String = "[]", width: Int = 0, height: Int = 0) {
        val result = Intent(ACTION_OCR_RESULT)
            .setPackage(packageName)
            .putExtra(EXTRA_TEXT, text)
            .putExtra(EXTRA_IMAGE_PATH, imagePath)
            .putExtra(EXTRA_WORD_BOXES, boxes)
            .putExtra(EXTRA_IMAGE_WIDTH, width)
            .putExtra(EXTRA_IMAGE_HEIGHT, height)
        sendBroadcast(result)
    }

    private fun releaseCapture(stopProjection: Boolean = true) {
        sessionActive = false
        captureRequested = false
        captureTimeout?.let { handler.removeCallbacks(it) }
        captureTimeout = null
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try {
            imageReader?.setOnImageAvailableListener(null, null)
            imageReader?.close()
        } catch (_: Exception) {}
        imageReader = null
        val oldProjection = projection
        projection = null
        if (stopProjection) try { oldProjection?.stop() } catch (_: Exception) {}
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "屏幕取词", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onDestroy() {
        releaseCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_OCR_RESULT = "com.pocketwords.app.OCR_RESULT"
        const val ACTION_CAPTURE_ONCE = "com.pocketwords.app.CAPTURE_ONCE"
        const val ACTION_STOP_CAPTURE = "com.pocketwords.app.STOP_CAPTURE"
        const val EXTRA_TEXT = "ocr_text"
        const val EXTRA_IMAGE_PATH = "ocr_image_path"
        const val EXTRA_WORD_BOXES = "ocr_word_boxes"
        const val EXTRA_IMAGE_WIDTH = "ocr_image_width"
        const val EXTRA_IMAGE_HEIGHT = "ocr_image_height"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        @Volatile var sessionActive: Boolean = false
            private set
        private const val CHANNEL_ID = "pocket_words_capture"
        private const val NOTIFICATION_ID = 731
        private const val STOP_REQUEST_CODE = 732
        private const val CAPTURE_TIMEOUT_MS = 5000L
    }
}
