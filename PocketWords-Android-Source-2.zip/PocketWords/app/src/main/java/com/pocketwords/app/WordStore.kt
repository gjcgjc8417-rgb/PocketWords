package com.pocketwords.app

import android.content.Context
import org.json.JSONArray

object WordStore {
    private const val PREFS = "pocket_words"
    private const val KEY_WORDS = "words"

    fun all(context: Context): List<String> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_WORDS, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.distinct()
    }

    fun add(context: Context, word: String): Boolean {
        val clean = word.trim().replace(Regex("\\s+"), " ")
        if (clean.isBlank()) return false
        val current = all(context)
        if (current.any { it.equals(clean, ignoreCase = true) }) return false
        val arr = JSONArray()
        (listOf(clean) + current).forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
        return true
    }

    fun delete(context: Context, word: String) {
        val arr = JSONArray()
        all(context).filterNot { it == word }.forEach { arr.put(it) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_WORDS, arr.toString()).apply()
    }
}
